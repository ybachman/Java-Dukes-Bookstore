/*
@author Yulia Bachman
 */

package javaeetutorial.dukesbookstore.ejb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 * <p>Singleton bean that initializes the book database for the bookstore
 * example.</p>
 */
@Singleton
@Startup
public class StateTaxConfigBean 
{
    @EJB
    private StateTaxRequestBean request;
    
    //Populate the StateTax table
    @PostConstruct
    public void createData() 
    {
        // Data based off http://www.tax-rates.org/taxtables/sales-tax-by-state
        request.createStateTax("Alabama", 0.04);
        request.createStateTax("Alaska", 0.00);
        request.createStateTax("Arizona", 0.056);
        request.createStateTax("Arkansas", 0.065);
        request.createStateTax("California", 0.075);
        request.createStateTax("Colorado", 0.029);
        request.createStateTax("Connecticut", 0.0635);
        request.createStateTax("Delaware", 0.00);
        request.createStateTax("District of Columbia", 0.0575);
        request.createStateTax("Florida", 0.06);
        request.createStateTax("Georgia", 0.04);
        request.createStateTax("Hawaii", 0.04);
        request.createStateTax("Idaho", 0.06);
        request.createStateTax("Illinois", 0.0625);
        request.createStateTax("Indiana", 0.07);
        request.createStateTax("Iowa", 0.06);
        request.createStateTax("Kansas", 0.065);
        request.createStateTax("Kentucky", 0.06);
        request.createStateTax("Louisiana", 0.04);
        request.createStateTax("Maine", 0.055);
        request.createStateTax("Maryland", 0.06);
        request.createStateTax("Massachusetts", 0.0625);
        request.createStateTax("Michigan", 0.06);
        request.createStateTax("Minnesota", 0.0688);
        request.createStateTax("Mississippi", 0.07);
        request.createStateTax("Missouri", 0.0423);
        request.createStateTax("Montana", 0.00);
        request.createStateTax("Nebraska", 0.055);
        request.createStateTax("Nevada", 0.0685);
        request.createStateTax("New Hampshire", 0.00);
        request.createStateTax("New Jersey", 0.07);
        request.createStateTax("New Mexico", 0.0513);
        request.createStateTax("New York", 0.04);
        request.createStateTax("North Carolina", 0.0475);
        request.createStateTax("North Dakota", 0.05);
        request.createStateTax("Ohio", 0.0575);
        request.createStateTax("Oklahoma", 0.045);
        request.createStateTax("Oregon", 0.00);
        request.createStateTax("Pennsylvania", 0.06);
        request.createStateTax("Puerto Rico", 0.06);
        request.createStateTax("Rhode Island", 0.07);
        request.createStateTax("South Carolina", 0.06);
        request.createStateTax("South Dakota", 0.04);
        request.createStateTax("Tennessee", 0.07);
        request.createStateTax("Texas", 0.0625);
        request.createStateTax("Utah", 0.0595);
        request.createStateTax("Vermont", 0.06);
        request.createStateTax("Virginia", 0.053);
        request.createStateTax("Washington", 0.065);
        request.createStateTax("West Virginia", 0.06);
        request.createStateTax("Wisconsin", 0.05);
        request.createStateTax("Wyoming", 0.04);
    }
}