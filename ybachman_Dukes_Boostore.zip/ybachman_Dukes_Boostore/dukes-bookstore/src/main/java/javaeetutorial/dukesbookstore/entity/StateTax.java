/*
@author Yulia Bachman
 */

package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * <p>Entity class for bookstore example.</p>
 */
@Entity
@Table(name = "STATE_TAX") //Create Table
@NamedQuery(
        //Query to be used
        name = "findTax",
        query = "SELECT t FROM StateTax t ORDER BY t.taxState")

public class StateTax implements Serializable
{
    //Set taxState as Primary Key
    @Id
    @NotNull
    private String taxState;
    private double tax;
    
    //Default Constructor
    public StateTax() 
    {}
    
    //Constructor
    public StateTax(String taxState, double tax)
    {
        this.taxState = taxState;
        this.tax = tax;
    }
    
    //Getters
    public String getTaxState() 
    {
        return taxState;
    }
    
    public double getTax() 
    {
        return tax;
    }
    
    //Setters
    public void setTaxState(String taxState) 
    {
        this.taxState = taxState;
    }
    
    public void setTax(double tax) 
    {
        this.tax = tax;
    }
    
    //Equals for database
    @Override
    public boolean equals(Object object) {
        if (!(object instanceof StateTax)) {
            return false;
        }
        StateTax other = (StateTax) object;
        return this.taxState != null || other.taxState == null 
                && this.taxState == null || this.taxState.equals(other.taxState);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.taxState);
        return hash;
    }
}